# Cytron_SmartDriveDuo

Arduino Library for Cytron Smart Drive Duo Motor Driver Series

Maintained by Idris ([idris@cytron.io](mailto:idris@cytron.io))

## Installing
- **Manual install:**
 
  Download the library as .zip file and extract it to Arduino libraries directory.
  
## Related tutorials
Coming soon...

## Contribution
1. Having an issue? or looking for support? [Open an issue](https://github.com/CytronTechnologies/Cytron_SmartDriveDuo/issues) or post in our [technical forum](http://forum.cytron.com.my/).
2. Got a new feature or a bug fix? Fork the repo, make your changes, and submit a pull request.
